<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TipoOrdenController extends BaseController
{
    //
}
