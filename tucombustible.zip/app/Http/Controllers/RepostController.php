<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RepostController extends BaseController
{
    //
}
