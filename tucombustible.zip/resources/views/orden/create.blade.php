@extends('layouts.app')

@section('title', 'Crear Nueva Orden de Trabajo')

@section('content')
<div class="row mb-4">
    <div class="col-12">
        <h1 class="mb-2">Crear Orden de Trabajo</h1>
        <p class="text-muted">Registra una nueva orden de reparación o mantenimiento.</p>
    </div>
</div>

<div class="card shadow-sm mb-4">
    <div class="card-header bg-white">
        <h5 class="card-title m-0">Datos de la Orden</h5>
    </div>
    <div class="card-body">
        <form action="{{ route('ordenes.store') }}" method="POST">
            @csrf
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="vehiculo_id" class="form-label">Vehículo</label>
                    <select class="form-select" id="vehiculo_id" name="id_vehiculo" required>
                        <option value="">Seleccione un vehículo</option>
                            @foreach ($vehiculos as $vehiculo)
                                <option value="{{ $vehiculo->id }}">{{ $vehiculo->placa }} - {{ $vehiculo->marca()->marca }} {{ $vehiculo->modelo()->modelo }}</option>
                            @endforeach 
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="nro_orden" class="form-label">Número de Orden</label>
                    <input type="text" class="form-control" disabled id="nro_orden" name="nro_orden" value="{{ $nro_orden }}" required>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="id_tipo_orden" class="form-label">Tipo de Orden</label>
                    <select class="form-select" id="id_tipo_orden" name="id_tipo_orden" required>
                        <option value="">Seleccione el tipo</option>
                        @foreach ($tipos as $tipo)
                            <option value="{{ $tipo->id_tipo_orden }}">{{ $tipo->nombre }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="kilometraje" class="form-label">Kilometraje</label>
                    <input type="number" class="form-control" id="kilometraje" name="kilometraje" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="responsable" class="form-label">Responsable Asignado</label>
                    <select class="form-select" id="responsable" name="responsable" required>
                        <option value="">Seleccione un responsable</option>
                            @foreach ($personal as $persona)
                                <option value="{{ $persona->id_personal }}">{{ $persona->nombre }} - {{ $persona->cargo }}</option>
                            @endforeach 
                    </select></div>
            </div>
            
            <div class="mb-3">
                <label for="descripcion_1" class="form-label">Descripción del Problema/Tarea</label>
                <textarea class="form-control" id="descripcion_1" name="descripcion_1" rows="4" required></textarea>
            </div>
            <div class="d-flex justify-content-between">
                <a href="{{ route('ordenes.list') }}" class="btn btn-secondary">Cancelar</a>
                <button type="submit" class="btn btn-primary">Guardar Orden</button>
            </div>
        </form>
    </div>
</div>
@endsection
