<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ModeloController extends BaseController
{
    //
}
