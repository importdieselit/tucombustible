<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Deposito;
use Illuminate\Database\Eloquent\ModelNotFoundException;

class DepositoController extends BaseController
{
    //
}
